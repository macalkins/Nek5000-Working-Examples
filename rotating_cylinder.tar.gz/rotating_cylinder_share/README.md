
Files for simulating rotating convection in a circular cylinder with a gmsh-generated mesh.

Mechanical boundary conditions: no-slip, impenetrable everywhere

Thermal boundary conditions: fixed temp on top and bottom, insulating on curved sidewall

The .geo file uses separate regions for the Ekman boundary layers on the top and bottom boundaries and the Stewartson boundary layer on the outer curved wall.

General Steps:

1) Edit parameters in cylinder.geo (aspect ratio, number of elements)

2) Generate mesh using gmsh and convert to Nek-friendly format:

gmsh -3 cylinder.geo -o cylinder.msh -format msh2 -bin 0

3) run gmsh2nek
4) run genmap using .re2 file

